package mainpage;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class CastVotePanel extends JFrame implements ActionListener {
    private int preFilledVoterId;
    private JLabel lblTitle, lblVoteID, lblVoterID, lblCandidates;
    private JTextField txtVoteID, txtVoterCast;
    private JButton btnCast, btnBack, btnCandidateDropdown;
    private JPopupMenu candidateMenu;
    private ArrayList<JCheckBox> candidateCheckBoxes;

    public CastVotePanel() {
        setTitle("E-VOTING SYSTEM - Cast Vote");
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        lblTitle = new JLabel("CAST VOTE", SwingConstants.CENTER);
        lblTitle.setBounds(180, 20, 200, 25);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        add(lblTitle);

        JLabel lblInstruction = new JLabel("Enter your Voter ID and select candidates");
        lblInstruction.setBounds(120, 50, 350, 25);
        add(lblInstruction);

        // Vote ID
        lblVoteID = new JLabel("Vote ID: ");
        lblVoteID.setBounds(100, 90, 100, 25);
        add(lblVoteID);

        txtVoteID = new JTextField();
        txtVoteID.setBounds(200, 90, 200, 25);
        txtVoteID.setEditable(false);
        add(txtVoteID);

        // Voter ID
        lblVoterID = new JLabel("Voter's ID: ");
        lblVoterID.setBounds(100, 130, 100, 25);
        add(lblVoterID);

        txtVoterCast = new JTextField();
        txtVoterCast.setBounds(200, 130, 200, 25);
        add(txtVoterCast);

        // Candidate dropdown button
        lblCandidates = new JLabel("Select Candidate: ");
        lblCandidates.setBounds(100, 170, 150, 25);
        add(lblCandidates);

        btnCandidateDropdown = new JButton("Choose Candidates:");
        btnCandidateDropdown.setBounds(200, 170, 200, 25);
        btnCandidateDropdown.addActionListener(this);
        add(btnCandidateDropdown);

        candidateMenu = new JPopupMenu();
        candidateCheckBoxes = new ArrayList<>();
        populateCandidatesDropdown();

        // Buttons
        btnCast = new JButton("Cast Vote");
        btnCast.setBounds(200, 220, 150, 30);
        btnCast.setBackground(Color.GREEN.darker());
        btnCast.setForeground(Color.WHITE);
        btnCast.addActionListener(this);
        add(btnCast);

        btnBack = new JButton("Back to Main");
        btnBack.setBounds(200, 270, 150, 30);
        btnBack.setBackground(Color.GRAY);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(this);
        add(btnBack);
        
        JLabel regisborder = new JLabel();
        regisborder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        regisborder.setBounds(70, 20, 390,310);
        add(regisborder);
        
        generateVoteID();
    }

    private void generateVoteID() {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1")) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM votes");
            int voteCount = 0;
            if (rs.next()) voteCount = rs.getInt(1);
            txtVoteID.setText(String.format("%02d", voteCount + 1));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error generating Vote ID: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateCandidatesDropdown() {
        candidateMenu.removeAll();
        candidateCheckBoxes.clear();

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1")) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT candidate_id, name, party FROM candidates");
            while (rs.next()) {
                String id = rs.getString("candidate_id");
                String name = rs.getString("name");
                String party = rs.getString("party");

                JCheckBox cb = new JCheckBox(id + " | " + name + " | " + party);
                cb.setBackground(Color.WHITE);
                candidateMenu.add(cb);
                candidateCheckBoxes.add(cb);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error loading candidates: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCandidateDropdown) {
            candidateMenu.show(btnCandidateDropdown, 0, btnCandidateDropdown.getHeight());
        } else if (e.getSource() == btnCast) {
            String voterIdStr = txtVoterCast.getText().trim();
            if (voterIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your Voter ID",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int voterIdNum;
            try {
                voterIdNum = Integer.parseInt(voterIdStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Voter ID must be a number!",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 1. VERIFY IN HASH TABLE (REAL DATA STRUCTURE)
            if (!RegistrationPanel.verifyVoterInHashTable(voterIdNum)) {
                JOptionPane.showMessageDialog(this,
                    "Voter not found or already voted!\n\n" +
                    "Hash Table Check Failed:\n" +
                    RegistrationPanel.getVoterInfo(voterIdNum),
                    "Verification Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ArrayList<String> selectedCandidates = new ArrayList<>();
            ArrayList<Integer> selectedCandidateIDs = new ArrayList<>();
            ArrayList<String> candidateNames = new ArrayList<>();
            
            for (JCheckBox cb : candidateCheckBoxes) {
                if (cb.isSelected()) {
                    selectedCandidates.add(cb.getText());
                    String[] parts = cb.getText().split("\\|");
                    int candId = Integer.parseInt(parts[0].trim());
                    String candName = parts[1].trim();
                    
                    selectedCandidateIDs.add(candId);
                    candidateNames.add(candName);
                }
            }

            if (selectedCandidates.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select at least one candidate!",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1")) {

                // 2. Get voter name from database
                String voterName = "";
                PreparedStatement psVoter = conn.prepareStatement(
                        "SELECT name FROM voters WHERE voter_id = ?");
                psVoter.setInt(1, voterIdNum);
                ResultSet rsVoter = psVoter.executeQuery();

                if (rsVoter.next()) {
                    voterName = rsVoter.getString("name");
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Voter not found in database!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // 3. Process each vote
                for (int i = 0; i < selectedCandidateIDs.size(); i++) {
                    int candId = selectedCandidateIDs.get(i);
                    String candName = candidateNames.get(i);
                    
                    // Add to database
                    PreparedStatement psInsert = conn.prepareStatement(
                            "INSERT INTO votes (voter_id, candidate_id) VALUES (?, ?)");
                    psInsert.setInt(1, voterIdNum);
                    psInsert.setInt(2, candId);
                    psInsert.executeUpdate();

                    PreparedStatement psUpdate = conn.prepareStatement(
                            "UPDATE candidates SET vote_count = vote_count + 1 WHERE candidate_id = ?");
                    psUpdate.setInt(1, candId);
                    psUpdate.executeUpdate();
                    // REMOVED: electionGraph.addVote(voterIdNum, candId);
                }

                // 4. Update voter status
                PreparedStatement psVoted = conn.prepareStatement(
                        "UPDATE voters SET has_voted = TRUE WHERE voter_id = ?");
                psVoted.setInt(1, voterIdNum);
                psVoted.executeUpdate();
                
                // 5. Update hash table (REAL DATA STRUCTURE)
                RegistrationPanel.markVoterVoted(voterIdNum);

                // Show success message
                StringBuilder votedList = new StringBuilder();
                for (String s : selectedCandidates) votedList.append("• ").append(s).append("\n");

                JOptionPane.showMessageDialog(this,
                        "✓ Vote Cast Successfully!\n\n" +
                        "Voter: " + voterName + " (ID: " + voterIdNum + ")\n\n" +
                        "You voted for:\n" + votedList.toString() +
                        "\nData Structures Updated:\n" +
                        "• Hash Table: Voter marked as voted\n" +
                        "• Database: Vote recorded",
                        "Success", JOptionPane.INFORMATION_MESSAGE);

                // Go back to main menu after voting
                new mainPage1().setVisible(true);
                this.dispose();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == btnBack) {
            new mainPage1().setVisible(true);
            this.dispose();
        }
    }
    
    public CastVotePanel(int voterId) {
        this();
        this.preFilledVoterId = voterId;
        txtVoterCast.setText(String.valueOf(voterId)); // Auto-fill the field
        txtVoterCast.setEditable(false); // Make it read-only so they can't change it
    }
}