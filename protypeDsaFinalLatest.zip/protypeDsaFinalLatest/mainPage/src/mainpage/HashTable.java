package mainpage;

import java.util.LinkedList;
import java.util.Iterator;

public class HashTable {
    private static final int SIZE = 100;
    private LinkedList<Entry>[] table;
    
    // INNER CLASS for Entry
    private class Entry {
        int key;
        VoterData value;
        
        Entry(int key, VoterData value) {
            this.key = key;
            this.value = value;
        }
    }
    
    // INNER CLASS for VoterData
    public class VoterData {
        private int voterId;
        private String name;
        private boolean hasVoted;
        
        public VoterData(int voterId, String name) {
            this.voterId = voterId;
            this.name = name;
            this.hasVoted = false;
        }
        
        public int getVoterId() {
            return voterId;
        }
        
        public String getName() {
            return name;
        }
        
        public boolean hasVoted() {
            return hasVoted;
        }
        
        public void setVoted(boolean voted) {
            this.hasVoted = voted;
        }
    }
    
    public HashTable() {
        table = new LinkedList[SIZE];
        for (int i = 0; i < SIZE; i++) {
            table[i] = new LinkedList<>();
        }
    }
    
    private int hash(int key) {
        return Math.abs(key % SIZE);
    }
    
    public void put(int voterId, VoterData voter) {
        int index = hash(voterId);
        LinkedList<Entry> chain = table[index];
        
        for (Entry entry : chain) {
            if (entry.key == voterId) {
                entry.value = voter;
                return;
            }
        }
        chain.add(new Entry(voterId, voter));
    }
    
    public VoterData get(int voterId) {
        int index = hash(voterId);
        LinkedList<Entry> chain = table[index];
        
        for (Entry entry : chain) {
            if (entry.key == voterId) {
                return entry.value;
            }
        }
        return null;
    }
    
    public boolean contains(int voterId) {
        return get(voterId) != null;
    }
    
    public void remove(int voterId) {
        int index = hash(voterId);
        LinkedList<Entry> chain = table[index];
        
        Iterator<Entry> iterator = chain.iterator();
        while (iterator.hasNext()) {
            Entry entry = iterator.next();
            if (entry.key == voterId) {
                iterator.remove();
                return;
            }
        }
    }
    
    public void display() {
        System.out.println("=== HASH TABLE CONTENTS ===");
        for (int i = 0; i < SIZE; i++) {
            if (!table[i].isEmpty()) {
                System.out.print("Bucket " + i + ": ");
                for (Entry entry : table[i]) {
                    System.out.print("[ID:" + entry.key + "->" + entry.value.getName() + "] ");
                }
                System.out.println();
            }
        }
    }
}