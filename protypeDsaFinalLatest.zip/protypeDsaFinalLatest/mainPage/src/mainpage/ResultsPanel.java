package mainpage;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ResultsPanel extends JFrame {
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private JButton backBtn, showGraphBtn;
    
    public ResultsPanel() {
        setTitle("E-Voting System - Election Results");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        // Title
        JLabel title = new JLabel("Election Results", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        add(title, BorderLayout.NORTH);
        
        // Results table
        String[] columns = {"Rank", "Candidate ID", "Name", "Party", "Votes"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        resultsTable = new JTable(tableModel);
        resultsTable.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        backBtn = new JButton("Back to Main");
        showGraphBtn = new JButton("Show Graph");
        
        backBtn.addActionListener(e -> {
            new mainPage1().setVisible(true);
            this.dispose();
        });
        
        showGraphBtn.addActionListener(e -> {
            showGraphStructure();
        });
        
        buttonPanel.add(backBtn);
        buttonPanel.add(showGraphBtn);
        
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load results
        loadResults();
    }
    
    private void loadResults() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1");
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT candidate_id, name, party, vote_count FROM candidates ORDER BY vote_count DESC");
            
            tableModel.setRowCount(0);
            int rank = 1;
            
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rank++,
                    rs.getInt("candidate_id"),
                    rs.getString("name"),
                    rs.getString("party"),
                    rs.getInt("vote_count")
                });
            }
            
            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading results: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void showGraphStructure() {
        // Create new ElectionGraph that reads from database
        ElectionGraph graph = new ElectionGraph();
        
        // Display graph in a dialog
        String graphInfo = graph.displayGraph();
        
        JDialog graphDialog = new JDialog(this, "Election Graph Structure", true);
        graphDialog.setSize(700, 500);
        graphDialog.setLayout(new BorderLayout());
        
        JTextArea graphText = new JTextArea(graphInfo);
        graphText.setFont(new Font("Monospaced", Font.PLAIN, 12));
        graphText.setEditable(false);
        
        JScrollPane scrollPane = new JScrollPane(graphText);
        graphDialog.add(scrollPane, BorderLayout.CENTER);
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> graphDialog.dispose());
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(closeButton);
        graphDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        graphDialog.setLocationRelativeTo(this);
        graphDialog.setVisible(true);
    }
}