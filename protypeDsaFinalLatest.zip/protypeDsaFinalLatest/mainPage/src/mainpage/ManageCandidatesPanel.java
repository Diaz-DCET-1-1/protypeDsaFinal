/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpage;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ManageCandidatesPanel extends JFrame implements ActionListener {

    private JLabel lblTitle;
    private JTable candidatesTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private JButton btnRefresh, btnDelete, btnClose;
    private JTextField txtSearch;
    private JButton btnSearch;

    public ManageCandidatesPanel() {
        setTitle("E-Voting System - Manage Candidates");
        setSize(800, 550); // Reduced height since we removed a button
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);

        // Title
        lblTitle = new JLabel("MANAGE CANDIDATES", SwingConstants.CENTER);
        lblTitle.setBounds(150, 20, 500, 40);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        add(lblTitle);

        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBounds(50, 70, 700, 40);
        
        JLabel lblSearch = new JLabel("Search:");
        txtSearch = new JTextField(20);
        btnSearch = new JButton("Search");
        btnSearch.setBackground(Color.GRAY);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(this);
        
        searchPanel.add(lblSearch);
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        add(searchPanel);

        // Table
        String[] columns = {"Candidate ID", "Name", "Party", "Votes"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        candidatesTable = new JTable(tableModel);
        candidatesTable.setFont(new Font("Arial", Font.PLAIN, 14));
        candidatesTable.setRowHeight(30);
        candidatesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        candidatesTable.getTableHeader().setBackground(Color.LIGHT_GRAY);
        candidatesTable.getTableHeader().setForeground(Color.BLACK);
        
        // Center alignment for ID and Votes columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        candidatesTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        candidatesTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        
        // Alternating row colors
        candidatesTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean isSelected,
                                                           boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(tbl, val, isSelected, hasFocus, row, col);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 240, 240));
                } else {
                    c.setBackground(new Color(180, 180, 180));
                }
                return c;
            }
        });

        scrollPane = new JScrollPane(candidatesTable);
        scrollPane.setBounds(50, 120, 700, 350);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        add(scrollPane);

        // Buttons (Removed Update Votes button)
        btnRefresh = new JButton("Refresh");
        btnDelete = new JButton("Delete Selected");
        btnClose = new JButton("Close");

        styleButton(btnRefresh);
        styleButton(btnDelete);
        styleButton(btnClose);

        btnRefresh.setBounds(150, 470, 120, 35);
        btnDelete.setBounds(320, 470, 150, 35);
        btnClose.setBounds(530, 470, 120, 35);

        add(btnRefresh);
        add(btnDelete);
        add(btnClose);

        // Border around content
        JLabel border = new JLabel();
        border.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        border.setBounds(40, 60, 720, 450);
        add(border);

        // Load initial data
        loadCandidates();

        // Action listeners
        btnRefresh.addActionListener(this);
        btnDelete.addActionListener(this);
        btnClose.addActionListener(this);
        btnSearch.addActionListener(this);
    }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setBackground(Color.GRAY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createRaisedBevelBorder());
    }

    private void loadCandidates() {
        loadCandidates(null);
    }
    
    private void loadCandidates(String searchTerm) {
        tableModel.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1")) {

            String query;
            PreparedStatement stmt;
            
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                query = "SELECT candidate_id, name, party, vote_count FROM candidates ORDER BY candidate_id";
                stmt = conn.prepareStatement(query);
            } else {
                query = "SELECT candidate_id, name, party, vote_count FROM candidates " +
                        "WHERE name LIKE ? OR party LIKE ? OR candidate_id = ? ORDER BY candidate_id";
                stmt = conn.prepareStatement(query);
                String searchPattern = "%" + searchTerm + "%";
                stmt.setString(1, searchPattern);
                stmt.setString(2, searchPattern);
                
                // Try to parse as ID
                try {
                    int id = Integer.parseInt(searchTerm);
                    stmt.setInt(3, id);
                } catch (NumberFormatException e) {
                    stmt.setInt(3, -1); // Invalid ID that won't match
                }
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("candidate_id"),
                        rs.getString("name"),
                        rs.getString("party"),
                        rs.getInt("vote_count")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading candidates: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteCandidate() {
        int selectedRow = candidatesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a candidate to delete",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int candidateId = (int) tableModel.getValueAt(selectedRow, 0);
        String candidateName = (String) tableModel.getValueAt(selectedRow, 1);
        int votes = (int) tableModel.getValueAt(selectedRow, 3);

        // Check if candidate has votes
        if (votes > 0) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Candidate " + candidateName + " has " + votes + " votes.\n" +
                    "Deleting will remove all votes for this candidate.\n" +
                    "Are you sure you want to delete?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Candidate?\nID: " + candidateId + "\nName: " + candidateName,
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1")) {

                // Start transaction
                conn.setAutoCommit(false);
                
                try {
                    // Delete votes for this candidate first (foreign key constraint)
                    PreparedStatement deleteVotes = conn.prepareStatement(
                            "DELETE FROM votes WHERE candidate_id = ?");
                    deleteVotes.setInt(1, candidateId);
                    deleteVotes.executeUpdate();
                    
                    // Delete candidate
                    PreparedStatement deleteCandidate = conn.prepareStatement(
                            "DELETE FROM candidates WHERE candidate_id = ?");
                    deleteCandidate.setInt(1, candidateId);
                    int rowsAffected = deleteCandidate.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        conn.commit();
                        JOptionPane.showMessageDialog(this,
                                "Candidate deleted successfully!\n" +
                                "Name: " + candidateName + "\n" +
                                votes + " votes were also removed.",
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        
                        loadCandidates();
                    }
                    
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                        "Error deleting candidate: " + e.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRefresh) {
            txtSearch.setText("");
            loadCandidates();
        } else if (e.getSource() == btnDelete) {
            deleteCandidate();
        } else if (e.getSource() == btnClose) {
            this.dispose();
        } else if (e.getSource() == btnSearch) {
            String searchTerm = txtSearch.getText().trim();
            loadCandidates(searchTerm);
        }
    }
}