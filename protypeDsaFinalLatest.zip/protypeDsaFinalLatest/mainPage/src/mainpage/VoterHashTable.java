/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpage;

import java.util.LinkedList;

public class VoterHashTable {
    private static final int TABLE_SIZE = 100;
    private LinkedList<Entry>[] table;
    
    private static class Entry {
        int voterId;
        String name;
        boolean hasVoted;
        
        Entry(int voterId, String name) {
            this.voterId = voterId;
            this.name = name;
            this.hasVoted = false;
        }
    }
    
    public VoterHashTable() {
        table = new LinkedList[TABLE_SIZE];
        for (int i = 0; i < TABLE_SIZE; i++) {
            table[i] = new LinkedList<>();
        }
    }
    
    private int hash(int voterId) {
        return Math.abs(voterId) % TABLE_SIZE;
    }
    
    public boolean addVoter(int voterId, String name) {
        int index = hash(voterId);
        
        // Check for duplicates
        for (Entry entry : table[index]) {
            if (entry.voterId == voterId) {
                return false; // Duplicate found
            }
        }
        
        // Add new voter
        table[index].add(new Entry(voterId, name));
        System.out.println("[Hash Table] Added voter " + voterId + " (" + name + ") at index " + index);
        return true;
    }
    
    public boolean verifyVoter(int voterId) {
        int index = hash(voterId);
        
        for (Entry entry : table[index]) {
            if (entry.voterId == voterId) {
                System.out.println("[Hash Table] Verified voter " + voterId + " at index " + index);
                return !entry.hasVoted; // Can vote if hasn't voted yet
            }
        }
        
        System.out.println("[Hash Table] Voter " + voterId + " not found");
        return false;
    }
    
    public boolean markVoted(int voterId) {
        int index = hash(voterId);
        
        for (Entry entry : table[index]) {
            if (entry.voterId == voterId) {
                if (!entry.hasVoted) {
                    entry.hasVoted = true;
                    System.out.println("[Hash Table] Marked voter " + voterId + " as voted");
                    return true;
                }
                return false; // Already voted
            }
        }
        
        return false; // Voter not found
    }
    
    public String getVoterInfo(int voterId) {
        int index = hash(voterId);
        
        for (Entry entry : table[index]) {
            if (entry.voterId == voterId) {
                return "ID: " + entry.voterId + ", Name: " + entry.name + 
                       ", Voted: " + (entry.hasVoted ? "Yes" : "No");
            }
        }
        
        return "Voter not found";
    }
    
    public String displayStructure() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== HASH TABLE STRUCTURE ===\n");
        sb.append("Size: ").append(TABLE_SIZE).append(" buckets\n");
        sb.append("Hash Function: voterId % ").append(TABLE_SIZE).append("\n");
        sb.append("Collision Handling: Separate Chaining\n\n");
        
        int totalVoters = 0;
        int collisions = 0;
        
        for (int i = 0; i < TABLE_SIZE; i++) {
            if (!table[i].isEmpty()) {
                sb.append("Bucket ").append(i).append(": ");
                if (table[i].size() > 1) collisions++;
                totalVoters += table[i].size();
                
                for (Entry entry : table[i]) {
                    sb.append("[ID:").append(entry.voterId)
                      .append("->").append(entry.name.substring(0, Math.min(10, entry.name.length())))
                      .append("] ");
                }
                sb.append("\n");
            }
        }
        
        sb.append("\n=== STATISTICS ===\n");
        sb.append("Total Voters: ").append(totalVoters).append("\n");
        sb.append("Collisions: ").append(collisions).append("\n");
        sb.append("Load Factor: ").append(String.format("%.2f", (float)totalVoters/TABLE_SIZE)).append("\n");
        
        return sb.toString();
    }
}