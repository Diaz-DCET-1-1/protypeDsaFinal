/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpage;

public class SortingAlgorithms {
    
    public static class Candidate {
        private int id;
        private String name;
        private String party;
        private int votes;
        
        public Candidate(int id, String name, String party, int votes) {
            this.id = id;
            this.name = name;
            this.party = party;
            this.votes = votes;
        }
        
        public int getId() { return id; }
        public String getName() { return name; }
        public String getParty() { return party; }
        public int getVotes() { return votes; }
        
        @Override
        public String toString() {
            return String.format("%-4d %-20s %-15s %-4d", id, name, party, votes);
        }
    }
    
    public static Candidate[] quickSort(Candidate[] candidates, StringBuilder log) {
        if (candidates == null || candidates.length == 0) {
            log.append("No candidates to sort\n");
            return candidates;
        }
        
        log.append("=== QUICK SORT EXECUTION ===\n");
        log.append("Input: ").append(candidates.length).append(" candidates\n\n");
        
        Candidate[] sorted = candidates.clone();
        quickSortHelper(sorted, 0, sorted.length - 1, log, 1);
        
        log.append("\nQuick Sort completed!\n");
        return sorted;
    }
    
    private static void quickSortHelper(Candidate[] arr, int low, int high, StringBuilder log, int depth) {
        if (low < high) {
            String indent = "  ".repeat(depth);
            log.append(indent).append("Partitioning [").append(low).append("...").append(high).append("]\n");
            
            int pivotIndex = partition(arr, low, high, log, depth);
            
            log.append(indent).append("Pivot at index ").append(pivotIndex)
               .append(" (Candidate ").append(arr[pivotIndex].getId())
               .append(" with ").append(arr[pivotIndex].getVotes()).append(" votes)\n");
            
            quickSortHelper(arr, low, pivotIndex - 1, log, depth + 1);
            quickSortHelper(arr, pivotIndex + 1, high, log, depth + 1);
        }
    }
    
    private static int partition(Candidate[] arr, int low, int high, StringBuilder log, int depth) {
        int pivot = arr[high].getVotes();
        int i = low - 1;
        String indent = "  ".repeat(depth);
        
        for (int j = low; j < high; j++) {
            if (arr[j].getVotes() >= pivot) { // Descending order
                i++;
                swap(arr, i, j);
                log.append(indent).append("  Swap ").append(j).append("↔").append(i)
                   .append(": ").append(arr[i].getVotes()).append(" ≥ ").append(pivot).append("\n");
            }
        }
        
        swap(arr, i + 1, high);
        return i + 1;
    }
    
    public static Candidate[] mergeSort(Candidate[] candidates, StringBuilder log) {
        if (candidates == null || candidates.length == 0) {
            log.append("No candidates to sort\n");
            return candidates;
        }
        
        log.append("=== MERGE SORT EXECUTION ===\n");
        log.append("Input: ").append(candidates.length).append(" candidates\n\n");
        
        Candidate[] sorted = candidates.clone();
        mergeSortHelper(sorted, 0, sorted.length - 1, log, 1);
        
        log.append("\nMerge Sort completed!\n");
        return sorted;
    }
    
    private static void mergeSortHelper(Candidate[] arr, int left, int right, StringBuilder log, int depth) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            String indent = "  ".repeat(depth);
            
            log.append(indent).append("Dividing [").append(left).append("...").append(right)
               .append("] into [").append(left).append("...").append(mid)
               .append("] and [").append(mid + 1).append("...").append(right).append("]\n");
            
            mergeSortHelper(arr, left, mid, log, depth + 1);
            mergeSortHelper(arr, mid + 1, right, log, depth + 1);
            
            log.append(indent).append("Merging [").append(left).append("...").append(mid)
               .append("] and [").append(mid + 1).append("...").append(right).append("]\n");
            
            merge(arr, left, mid, right, log, depth);
        }
    }
    
    private static void merge(Candidate[] arr, int left, int mid, int right, StringBuilder log, int depth) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        
        Candidate[] leftArr = new Candidate[n1];
        Candidate[] rightArr = new Candidate[n2];
        
        for (int i = 0; i < n1; i++) leftArr[i] = arr[left + i];
        for (int j = 0; j < n2; j++) rightArr[j] = arr[mid + 1 + j];
        
        int i = 0, j = 0, k = left;
        String indent = "  ".repeat(depth);
        
        while (i < n1 && j < n2) {
            if (leftArr[i].getVotes() >= rightArr[j].getVotes()) {
                arr[k] = leftArr[i];
                log.append(indent).append("  Take from left: ").append(leftArr[i].getVotes())
                   .append(" ≥ ").append(rightArr[j].getVotes()).append("\n");
                i++;
            } else {
                arr[k] = rightArr[j];
                log.append(indent).append("  Take from right: ").append(rightArr[j].getVotes())
                   .append(" > ").append(leftArr[i].getVotes()).append("\n");
                j++;
            }
            k++;
        }
        
        while (i < n1) {
            arr[k] = leftArr[i];
            i++;
            k++;
        }
        
        while (j < n2) {
            arr[k] = rightArr[j];
            j++;
            k++;
        }
    }
    
    public static Candidate[] bubbleSort(Candidate[] candidates, StringBuilder log) {
        if (candidates == null || candidates.length == 0) {
            log.append("No candidates to sort\n");
            return candidates;
        }
        
        log.append("=== BUBBLE SORT EXECUTION ===\n");
        log.append("Input: ").append(candidates.length).append(" candidates\n\n");
        
        Candidate[] sorted = candidates.clone();
        int n = sorted.length;
        boolean swapped;
        
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            log.append("Pass ").append(i + 1).append(":\n");
            
            for (int j = 0; j < n - i - 1; j++) {
                if (sorted[j].getVotes() < sorted[j + 1].getVotes()) {
                    swap(sorted, j, j + 1);
                    swapped = true;
                    log.append("  Swap ").append(j).append("↔").append(j + 1)
                       .append(": ").append(sorted[j].getVotes()).append(" < ").append(sorted[j + 1].getVotes()).append("\n");
                }
            }
            
            if (!swapped) {
                log.append("  No swaps - array is sorted!\n");
                break;
            }
        }
        
        log.append("\nBubble Sort completed!\n");
        return sorted;
    }
    
    private static void swap(Candidate[] arr, int i, int j) {
        Candidate temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    public static String displayCandidates(Candidate[] candidates, String title) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ").append(title).append(" ===\n");
        sb.append("Rank  ID   Name                Party          Votes\n");
        sb.append("---------------------------------------------------\n");
        
        for (int i = 0; i < candidates.length; i++) {
            sb.append(String.format("%-5d %s\n", i + 1, candidates[i]));
        }
        
        return sb.toString();
    }
}