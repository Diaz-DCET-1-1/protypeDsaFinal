package mainpage;

import java.util.*;
import java.sql.*;

public class ElectionGraph {
    
    public String displayGraph() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ELECTION GRAPH STRUCTURE ===\n\n");
        
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_system", "root", "DCET2-1");
            
            // Get all votes from database
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT v.voter_id, v2.name as voter_name, " +
                "c.candidate_id, c.name as candidate_name " +
                "FROM votes v " +
                "JOIN voters v2 ON v.voter_id = v2.voter_id " +
                "JOIN candidates c ON v.candidate_id = c.candidate_id " +
                "ORDER BY v.voter_id");
            
            // Group votes by voter
            Map<Integer, List<String>> voterVotes = new TreeMap<>();
            Map<Integer, List<String>> candidateVoters = new TreeMap<>();
            Set<Integer> voters = new HashSet<>();
            Set<Integer> candidates = new HashSet<>();
            
            boolean hasData = false;
            
            while (rs.next()) {
                hasData = true;
                int voterId = rs.getInt("voter_id");
                String voterName = rs.getString("voter_name");
                int candidateId = rs.getInt("candidate_id");
                String candidateName = rs.getString("candidate_name");
                
                // Add to voter's votes
                String voteInfo = candidateId + " - " + candidateName;
                voterVotes.computeIfAbsent(voterId, k -> new ArrayList<>()).add(voteInfo);
                
                // Add to candidate's voters
                String voterInfo = voterId + " - " + voterName;
                candidateVoters.computeIfAbsent(candidateId, k -> new ArrayList<>()).add(voterInfo);
                
                voters.add(voterId);
                candidates.add(candidateId);
            }
            
            conn.close();
            
            if (!hasData) {
                sb.append("No votes cast yet.\n");
                return sb.toString();
            }
            
            sb.append("VOTERS AND THEIR VOTES:\n");
            for (Map.Entry<Integer, List<String>> entry : voterVotes.entrySet()) {
                sb.append("Voter ").append(entry.getKey()).append(" voted for:\n");
                for (String vote : entry.getValue()) {
                    sb.append("  → Candidate ").append(vote).append("\n");
                }
            }
            
            sb.append("\nCANDIDATES AND THEIR VOTERS:\n");
            for (Map.Entry<Integer, List<String>> entry : candidateVoters.entrySet()) {
                sb.append("Candidate ").append(entry.getKey())
                  .append(" has ").append(entry.getValue().size()).append(" votes:\n");
                for (String voter : entry.getValue()) {
                    sb.append("  ← Voter ").append(voter).append("\n");
                }
            }
            
            sb.append("\n=== GRAPH STATISTICS ===\n");
            sb.append("Total Voters who voted: ").append(voters.size()).append("\n");
            sb.append("Total Candidates voted for: ").append(candidates.size()).append("\n");
            
            // Count total votes
            int totalVotes = 0;
            for (List<String> votes : voterVotes.values()) {
                totalVotes += votes.size();
            }
            sb.append("Total Votes: ").append(totalVotes).append("\n");
            
        } catch (SQLException e) {
            sb.append("Error reading database: ").append(e.getMessage()).append("\n");
        }
        
        return sb.toString();
    }
}