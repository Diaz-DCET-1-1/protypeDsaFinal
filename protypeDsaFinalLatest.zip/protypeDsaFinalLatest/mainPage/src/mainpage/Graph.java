/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpage;

import java.util.*;

public class Graph {
    private Map<Integer, List<Integer>> adjacencyList;
    
    public Graph() {
        adjacencyList = new HashMap<>();
    }
    
    // Add voter node
    public void addVoter(int voterId) {
        adjacencyList.putIfAbsent(voterId, new ArrayList<>());
    }
    
    // Add candidate node
    public void addCandidate(int candidateId) {
        adjacencyList.putIfAbsent(candidateId, new ArrayList<>());
    }
    
    // Add edge: voter voted for candidate
    public void addVote(int voterId, int candidateId) {
        adjacencyList.putIfAbsent(voterId, new ArrayList<>());
        adjacencyList.putIfAbsent(candidateId, new ArrayList<>());
        
        // Voter -> Candidate
        adjacencyList.get(voterId).add(candidateId);
        // Candidate <- Voter (bidirectional for some analysis)
        adjacencyList.get(candidateId).add(voterId);
    }
    
    // Get all candidates a voter voted for
    public List<Integer> getCandidatesByVoter(int voterId) {
        return adjacencyList.getOrDefault(voterId, new ArrayList<>());
    }
    
    // Get all voters who voted for a candidate
    public List<Integer> getVotersByCandidate(int candidateId) {
        return adjacencyList.getOrDefault(candidateId, new ArrayList<>());
    }
    
    // Get voting pattern statistics
    public Map<Integer, Integer> getVotingPatterns() {
        Map<Integer, Integer> patterns = new HashMap<>();
        
        for (Map.Entry<Integer, List<Integer>> entry : adjacencyList.entrySet()) {
            if (entry.getKey() > 1000) { // Assuming candidate IDs > 1000
                patterns.put(entry.getKey(), entry.getValue().size());
            }
        }
        return patterns;
    }
}